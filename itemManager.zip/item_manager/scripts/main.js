// scripts/main.ts
import {
  world as world2,
  system as system2,
  EquipmentSlot,
  CommandPermissionLevel,
  CustomCommandStatus
} from "@minecraft/server";

// scripts/API/FORMS/forms.ts
import { system, world } from "@minecraft/server";
import { ActionFormData, MessageFormData, ModalFormData } from "@minecraft/server-ui";

// scripts/API/FORMS/text.ts
function isObject(value) {
  return !!value && typeof value === "object" && !Array.isArray(value);
}
function isRawMessage(value) {
  if (!isObject(value)) return false;
  return "rawtext" in value || "text" in value || "translate" in value || "with" in value || "score" in value || "selector" in value;
}
function isFormText(value) {
  return typeof value === "string" || isRawMessage(value);
}

// scripts/API/FORMS/formErrors.ts
var FormsError = class extends Error {
  constructor(message, code = "FORMS_ERROR", details) {
    super(message);
    this.name = "FormsError";
    this.code = code;
    this.details = details;
  }
};
var InvalidPlayerError = class extends FormsError {
  constructor(details) {
    super("Invalid player supplied to Forms.", "INVALID_PLAYER", details);
    this.name = "InvalidPlayerError";
  }
};
var ValidationError = class extends FormsError {
  constructor(message, details) {
    super(message, "VALIDATION_ERROR", details);
    this.name = "ValidationError";
  }
};
var FormDisplayError = class extends FormsError {
  constructor(message, details) {
    super(message, "FORM_DISPLAY_ERROR", details);
    this.name = "FormDisplayError";
  }
};
var FormCallbackError = class extends FormsError {
  constructor(message, details) {
    super(message, "FORM_CALLBACK_ERROR", details);
    this.name = "FormCallbackError";
  }
};

// scripts/API/FORMS/forms.ts
var IssueCollector = class {
  constructor() {
    this.issues = [];
  }
  error(path, message) {
    this.issues.push({ level: "error", path, message });
  }
  warning(path, message) {
    this.issues.push({ level: "warning", path, message });
  }
  result() {
    const errors = this.issues.filter((i) => i.level === "error");
    const warnings = this.issues.filter((i) => i.level === "warning");
    return {
      valid: errors.length === 0,
      errors,
      warnings,
      issues: this.issues
    };
  }
};
var Forms = class {
  static {
    this.config = {
      debug: false,
      strict: true,
      logWarnings: true,
      logToChat: false,
      chatTag: "debug",
      prefix: "[Forms+]",
      busyHandling: "retry",
      maxBusyRetries: 500,
      validateOnShow: true
    };
  }
  /* CONFIG */
  static configure(config) {
    this.config = { ...this.config, ...config };
    if (!Number.isInteger(this.config.maxBusyRetries) || this.config.maxBusyRetries < 0) {
      this.config.maxBusyRetries = 0;
    }
    if (!this.config.prefix.trim()) this.config.prefix = "[Forms+]";
    if (!this.config.chatTag.trim()) this.config.chatTag = "debug";
  }
  static getConfig() {
    return { ...this.config };
  }
  /* DEBUG */
  static debugLog(scope, result) {
    if (!this.config.debug || result.issues.length === 0) return;
    const filtered = result.issues.filter((i) => i.level === "error" || this.config.logWarnings);
    if (!filtered.length) return;
    const text = `${this.config.prefix} ${scope}
` + filtered.map((i) => `${i.level.toUpperCase()} | ${i.path} | ${i.message}`).join("\n");
    console.warn(text);
    if (!this.config.logToChat) return;
    for (const player of world.getAllPlayers()) {
      try {
        if (player.hasTag(this.config.chatTag)) player.sendMessage(text);
      } catch (e) {
        console.warn("Chat debug failed:", e);
      }
    }
  }
  static handleValidation(scope, result) {
    this.debugLog(scope, result);
    if (result.valid) return true;
    if (this.config.strict) {
      throw new ValidationError(
        `${this.config.prefix} ${scope} validation failed:
` + result.errors.map((i) => `[${i.path}] ${i.message}`).join("\n"),
        result
      );
    }
    return false;
  }
  /* VALIDATION */
  static validatePlayer(player) {
    const v = new IssueCollector();
    if (!player) {
      v.error("player", "Player is required.");
      return v.result();
    }
    if (!player.isValid) v.error("player", "Player is not valid.");
    return v.result();
  }
  static validateActionForm(options) {
    const v = new IssueCollector();
    if (!options || typeof options !== "object") {
      v.error("options", "Must be object.");
      return v.result();
    }
    if (options.title && !isFormText(options.title)) v.error("title", "Invalid");
    if (options.body && !isFormText(options.body)) v.error("body", "Invalid");
    if (!Array.isArray(options.items) || !options.items.length) {
      v.error("items", "At least one item required.");
      return v.result();
    }
    let buttonCount = 0;
    options.items.forEach((item, i) => {
      const path = `items[${i}]`;
      if (!item || typeof item !== "object") return v.error(path, "Invalid item");
      if (item.kind === "button") {
        buttonCount++;
        if (!isFormText(item.text)) v.error(`${path}.text`, "Invalid");
      }
    });
    if (options.actions && options.actions.length !== buttonCount) {
      v.warning("actions", "Actions length does not match buttons.");
    }
    if (!buttonCount) v.error("items", "Needs button");
    return v.result();
  }
  static validateMessageForm(options) {
    const v = new IssueCollector();
    if (!options.button1 || !options.button2) {
      v.error("buttons", "button1 and button2 are required");
    }
    return v.result();
  }
  static validateModalForm(options) {
    const v = new IssueCollector();
    if (!Array.isArray(options.controls)) {
      v.error("controls", "Controls must be an array");
    }
    return v.result();
  }
  /* INTERNAL */
  static showForm(form, player) {
    return new Promise((resolve) => {
      system.run(async () => resolve(await form.show(player)));
    });
  }
  static async showWithRetry(fn) {
    const max = this.config.busyHandling === "retry" ? this.config.maxBusyRetries : 0;
    for (let i = 0; i <= max; i++) {
      const res = await fn();
      if (res?.cancelationReason === "UserBusy" && i < max) continue;
      return res;
    }
    throw new FormDisplayError("Max retries hit");
  }
  static async safe(scope, fn) {
    try {
      await fn();
    } catch (e) {
      throw new FormCallbackError(`${scope} failed`, e);
    }
  }
  /* ACTION */
  static async action(player, options) {
    const playerValidation = this.validatePlayer(player);
    if (!playerValidation.valid) {
      if (this.config.strict) throw new InvalidPlayerError(playerValidation);
      return { canceled: true, reason: "invalid_player" };
    }
    if (this.config.validateOnShow) {
      if (!this.handleValidation("ActionForm", this.validateActionForm(options))) {
        return { canceled: true, reason: "validation_failed" };
      }
    }
    const form = new ActionFormData();
    options.title && form.title(options.title);
    options.body && form.body(options.body);
    for (const item of options.items) {
      if (item.kind === "button") form.button(item.text, item.iconPath);
      if (item.kind === "header") form.header(item.text);
      if (item.kind === "label") form.label(item.text);
      if (item.kind === "divider") form.divider();
    }
    const res = await this.showWithRetry(() => this.showForm(form, player));
    if (res.canceled || res.selection === void 0) {
      return { canceled: true, reason: "canceled", response: res };
    }
    const i = res.selection;
    await this.safe("action", async () => {
      await options.actions?.[i]?.(player);
      await options.onSelect?.(i, player);
    });
    return { canceled: false, data: i, response: res };
  }
  /* MESSAGE */
  static async message(player, options) {
    if (this.config.validateOnShow) {
      if (!this.handleValidation("MessageForm", this.validateMessageForm(options))) {
        return { canceled: true, reason: "validation_failed" };
      }
    }
    const form = new MessageFormData();
    options.title && form.title(options.title);
    options.body && form.body(options.body);
    form.button1(options.button1.text);
    form.button2(options.button2.text);
    const res = await this.showWithRetry(() => this.showForm(form, player));
    if (res.canceled || res.selection === void 0) {
      return { canceled: true, reason: "canceled", response: res };
    }
    const i = res.selection;
    await this.safe("message", async () => {
      await options.actions?.[i]?.(player);
      await options.onSelect?.(i, player);
    });
    return { canceled: false, data: i, response: res };
  }
  /* MODAL */
  static async modal(player, options) {
    if (this.config.validateOnShow) {
      if (!this.handleValidation("ModalForm", this.validateModalForm(options))) {
        return { canceled: true, reason: "validation_failed" };
      }
    }
    const form = new ModalFormData();
    options.title && form.title(options.title);
    options.submitButton && form.submitButton(options.submitButton);
    for (const c of options.controls) {
      switch (c.type) {
        case "textField":
          form.textField(c.label, c.placeholder ?? "", { defaultValue: c.defaultValue });
          break;
        case "slider":
          form.slider(c.label, c.min, c.max, { defaultValue: c.defaultValue ?? c.min });
          break;
        case "toggle":
          form.toggle(c.label, { defaultValue: c.defaultValue ?? false });
          break;
        case "dropdown":
          form.dropdown(c.label, c.options, { defaultValueIndex: c.defaultValueIndex ?? 0 });
          break;
        case "header":
          form.header(c.text);
          break;
        case "label":
          form.label(c.text);
          break;
        case "divider":
          form.divider();
          break;
      }
    }
    const res = await this.showWithRetry(() => this.showForm(form, player));
    if (res.canceled || !res.formValues) {
      return { canceled: true, reason: "canceled", response: res };
    }
    const values = res.formValues;
    await this.safe("modal", async () => {
      if (options.actions) {
        for (const key of Object.keys(options.actions)) {
          const fn = options.actions[key];
          if (fn && values[key] !== void 0) {
            await fn(values[key], values, player);
          }
        }
      }
      await options.onSubmit?.(values, player);
    });
    return { canceled: false, data: values, response: res };
  }
};

// scripts/main.ts
var itemDB = /* @__PURE__ */ new Map();
var cooldown = /* @__PURE__ */ new Map();
function uid() {
  return Math.random().toString(36).substring(2, 10);
}
function getItemMeta(item) {
  return item.getDynamicProperty("wisp:id") ?? "";
}
function setItemMeta(item, id, player) {
  const clone = item.clone();
  clone.amount = 1;
  clone.setDynamicProperty("wisp:id", id);
  player.getComponent("inventory").container.setItem(player.selectedSlotIndex, clone);
}
system2.beforeEvents.startup.subscribe(({ customCommandRegistry }) => {
  customCommandRegistry.registerCommand(
    {
      name: "wisp:itemmanager",
      description: "Open UI",
      permissionLevel: CommandPermissionLevel.Any,
      cheatsRequired: false
    },
    (origin) => {
      if (!origin.sourceEntity) return { status: CustomCommandStatus.Failure };
      system2.run(() => main(origin.sourceEntity));
      return { status: CustomCommandStatus.Success };
    }
  );
});
async function main(player) {
  await Forms.action(player, {
    title: "Item Manager",
    items: [
      { kind: "button", text: "Add Items" },
      { kind: "button", text: "View Items" }
    ],
    onSelect: async (i) => {
      if (i === 0) await addMenu(player);
      if (i === 1) await viewItems(player);
    }
  });
}
async function addMenu(player) {
  await Forms.action(player, {
    title: "Add Items",
    items: [
      { kind: "button", text: "TypeID (global)" },
      { kind: "button", text: "Held Item (meta)" }
    ],
    onSelect: async (i) => {
      if (i === 0) await addByType(player);
      if (i === 1) await addByHeld(player);
    }
  });
}
var triggerList = [
  "holding",
  "offhand",
  "used",
  "dropped",
  "obtained",
  "sneaking",
  "jumping"
];
async function addByType(player) {
  await Forms.modal(player, {
    title: "TypeID",
    controls: [
      { type: "textField", label: "Item ID" },
      { type: "dropdown", label: "Trigger", options: triggerList },
      { type: "textField", label: "Command Count" }
    ],
    submitButton: "Next",
    onSubmit: async (v) => {
      const item = String(v[0] ?? "");
      const action = triggerList[Number(v[1])];
      const count = Math.max(1, parseInt(String(v[2] ?? "1")));
      await addCommands(player, item, action, count, true);
    }
  });
}
async function addByHeld(player) {
  const inv = player.getComponent("inventory")?.container;
  const held = inv?.getItem(player.selectedSlotIndex);
  if (!held) return player.sendMessage("\xA7cHold item");
  await Forms.modal(player, {
    title: "Held Item",
    controls: [
      { type: "dropdown", label: "Trigger", options: triggerList },
      { type: "textField", label: "Command Count" }
    ],
    submitButton: "Next",
    onSubmit: async (v) => {
      const action = triggerList[Number(v[0])];
      const count = Math.max(1, parseInt(String(v[1] ?? "1")));
      await addCommands(player, held.typeId, action, count, false, held);
    }
  });
}
async function addCommands(player, item, action, count, global, heldItem) {
  const controls = Array.from({ length: count }, (_, i) => ({
    type: "textField",
    label: `Command ${i + 1}`
  }));
  await Forms.modal(player, {
    title: "Commands",
    controls,
    submitButton: "Save",
    onSubmit: (values) => {
      const commands = values.map((v) => String(v ?? "").trim()).filter((v) => v);
      if (!commands.length) return player.sendMessage("\xA7cNo commands");
      const id = uid();
      const entry = { id, name: item, action, commands, global };
      if (!itemDB.has(item)) itemDB.set(item, []);
      itemDB.get(item).push(entry);
      if (!global && heldItem) setItemMeta(heldItem, id, player);
      player.sendMessage(`\xA7aSaved`);
    }
  });
}
async function viewItems(player) {
  const keys = [...itemDB.keys()];
  if (!keys.length) return player.sendMessage("\xA7cNo items");
  await Forms.action(player, {
    title: "Items",
    items: keys.map((k) => ({ kind: "button", text: k })),
    onSelect: async (i) => {
      const key = keys[i];
      const entries = itemDB.get(key);
      if (!entries) return;
      await Forms.action(player, {
        title: key,
        items: entries.map((e) => ({
          kind: "button",
          text: `${e.global ? "GLOBAL" : "META"} | ${e.action}`
        }))
      });
    }
  });
}
world2.afterEvents.itemUse.subscribe((e) => {
  check(e.source, e.itemStack, "used");
});
world2.afterEvents.playerInventoryItemChange.subscribe((e) => {
  if (e.itemStack) {
    check(e.player, e.itemStack, "obtained");
  }
});
system2.runInterval(() => {
  for (const player of world2.getAllPlayers()) {
    const inv = player.getComponent("inventory")?.container;
    if (!inv) continue;
    const selected = inv.getItem(player.selectedSlotIndex);
    const offhand = player.getComponent("equippable")?.getEquipment(EquipmentSlot.Offhand);
    check(player, selected, "holding");
    check(player, offhand, "offhand");
    if (player.isSneaking) check(player, selected, "sneaking");
    if (player.getVelocity().y > 0.2) check(player, selected, "jumping");
  }
}, 20);
function check(player, item, type) {
  if (!item) return;
  const entries = itemDB.get(item.typeId);
  if (!entries) return;
  const meta = getItemMeta(item);
  for (const e of entries) {
    if (e.global && e.action === type) runCommands(player, e.commands);
    if (!e.global && e.id === meta && e.action === type) runCommands(player, e.commands);
  }
}
function runCommands(player, commands) {
  const now = Date.now();
  const last = cooldown.get(player.id) ?? 0;
  if (now - last < 1e3) return;
  cooldown.set(player.id, now);
  for (const cmd of commands) {
    try {
      player.runCommand(cmd);
    } catch {
    }
  }
}

//# sourceMappingURL=../debug/main.js.map
